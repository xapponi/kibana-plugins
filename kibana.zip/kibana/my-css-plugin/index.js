export default function (kibana) {
return new kibana.Plugin({
"version": "6.6.1",
id: 'my-css-plugin',
require: ['kibana', 'elasticsearch'],
uiExports: {
  hacks: [
    'kibana-plugins/my-css-plugin/hack'
  ]
}
});
};
