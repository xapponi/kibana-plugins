export default function (kibana) {
return new kibana.Plugin({
id: 'my-css-plugin',
require: ['kibana', 'elasticsearch'],
uiExports: {
  hacks: [
    'kibana-plugins/my-css-plugin/hack'
  ]
}
});
};
