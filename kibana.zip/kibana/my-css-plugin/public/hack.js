import 'kibana-plugins/my-css_plugin/less/main.less';
